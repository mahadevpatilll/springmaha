package com.technoelevate.springpgitex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringpgitexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringpgitexApplication.class, args);
	}

}
